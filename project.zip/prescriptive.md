#### Changes
* Must require use of System.out and a BufferedReader

#### Moar prescription
1. Jar class has a constructor that takes a string and an integer
1. (MOVED TO MEETS) Ensure the random is incremented zero, and top.
1. Prompt asks for "What type of item"
1. Prompt asks for "Maximum number of **items**" where **items** is replaced with name of the previously prompted items.
1. User is presented with the starts of the game "How many **items** are in the Jar. Pick a number between 1 and **max amount**:"


#### Exceeds prescriptiveness
1. Prompt warns of "Guess must between 1 and **max**"
1. Prompt warns "Your guess is too high"
1. Prompt warns "Your guess is too low"
